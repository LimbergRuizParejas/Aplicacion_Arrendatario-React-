import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, Image,
  ScrollView, ActivityIndicator
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Reservations'>;

interface Reservation {
  id: number;
  cliente: string;
  noches: number;
  fechaLlegada: string;
  fechaSalida: string;
  total: number;
  imagen: string;
}

export default function ReservationsScreen({ route }: Props) {
  const { placeId } = route.params;

  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadReservations = async () => {
      try {
        // Simulación de llamada al backend
        const fakeData: Reservation[] = [
          {
            id: 1, cliente: 'Juan Pérez', noches: 3,
            fechaLlegada: '2025-07-05', fechaSalida: '2025-07-08',
            total: 360, imagen: 'https://via.placeholder.com/300x200?text=Reserva+1'
          },
          {
            id: 2, cliente: 'Ana Gómez', noches: 2,
            fechaLlegada: '2025-07-10', fechaSalida: '2025-07-12',
            total: 240, imagen: 'https://via.placeholder.com/300x200?text=Reserva+2'
          },
        ];
        setReservations(fakeData);
      } catch (err) {
        console.error('❌ Error al cargar reservas:', err);
      } finally {
        setLoading(false);
      }
    };

    loadReservations();
  }, [placeId]);

  const renderItem = ({ item }: { item: Reservation }) => (
    <View style={styles.card}>
      <Image
        source={{ uri: item.imagen }}
        style={styles.image}
      />
      <View style={styles.info}>
        <Text style={styles.client}>{item.cliente}</Text>
        <Text style={styles.details}>
          {item.noches} noches — {item.fechaLlegada} a {item.fechaSalida}
        </Text>
        <Text style={styles.total}>Total: ${item.total}</Text>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007BFF" />
        <Text style={styles.loadingText}>Cargando reservas...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Reservas del Lugar</Text>
      <Text style={styles.subtitle}>ID del lugar: {placeId}</Text>

      {reservations.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No hay reservas registradas para este lugar.</Text>
        </View>
      ) : (
        <FlatList
          data={reservations}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 20, backgroundColor: '#fff' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 10, fontSize: 16, color: '#555' },
  title: { fontSize: 26, fontWeight: 'bold', marginBottom: 10 },
  subtitle: { fontSize: 18, color: '#555', marginBottom: 20 },
  card: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 2
  },
  image: {
    width: 80,
    height: 60,
    borderRadius: 4,
    marginRight: 15,
    backgroundColor: '#ddd'
  },
  info: { flex: 1 },
  client: { fontSize: 16, fontWeight: 'bold' },
  details: { fontSize: 14, color: '#555', marginTop: 2 },
  total: { fontSize: 15, color: '#007BFF', marginTop: 5 },
  emptyContainer: { alignItems: 'center', marginTop: 50 },
  emptyText: { fontSize: 16, color: '#777' }
});
