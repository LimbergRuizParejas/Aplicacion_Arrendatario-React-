import React, { useState } from 'react';
import {
  View, TextInput, Button, StyleSheet, Alert, Text
} from 'react-native';
import { register } from '../services/authService';
import axios from 'axios';

export default function RegisterScreen() {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [telefono, setTelefono] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = async () => {
    if (!nombre || !email || !telefono || !password) {
      Alert.alert('Error', 'Por favor completa todos los campos');
      return;
    }

    const payload = {
      nombrecompleto: nombre,
      email,
      telefono,
      password,
    };

    console.log('📤 Enviando registro con:', payload);

    try {
      const response = await register(payload);
      console.log('✅ Registro exitoso:', response);
      Alert.alert('Éxito', 'Registro completado');

      // Limpiar formulario
      setNombre('');
      setEmail('');
      setTelefono('');
      setPassword('');
    } catch (error: any) {
      if (axios.isAxiosError(error)) {
        console.error('❌ Error en registro (Axios):', error.response?.data || error.message);
        Alert.alert('Error', error.response?.data?.message || 'Ocurrió un error en el servidor');
      } else {
        console.error('❌ Error inesperado:', error);
        Alert.alert('Error', 'Ocurrió un error inesperado');
      }
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Registro</Text>
      <TextInput
        placeholder="Nombre Completo"
        value={nombre}
        onChangeText={setNombre}
        style={styles.input}
        autoCapitalize="words"
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
      />
      <TextInput
        placeholder="Teléfono"
        value={telefono}
        onChangeText={setTelefono}
        style={styles.input}
        keyboardType="phone-pad"
      />
      <TextInput
        placeholder="Contraseña"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
      />
      <Button title="Registrarse" onPress={handleRegister} color="#28a745" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, justifyContent: 'center', padding: 20
  },
  title: {
    fontSize: 26, fontWeight: 'bold',
    marginBottom: 25, textAlign: 'center',
    color: '#007BFF'
  },
  input: {
    borderWidth: 1, borderColor: '#ccc',
    padding: 12, marginBottom: 20, borderRadius: 8,
    fontSize: 16
  }
});
